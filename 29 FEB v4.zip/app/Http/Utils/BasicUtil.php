<?php

namespace App\Http\Utils;

use App\Models\EmployeePensionHistory;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Session;

trait BasicUtil
{
    // this function do all the task and returns transaction id or -1

    public function fieldsHaveChanged($fields_to_check, $entity1, $entity2, $date_fields) {
        foreach ($fields_to_check as $field) {
            $value1 = $entity1->$field;
            $value2 = $entity2[$field];

            // Additional formatting if needed
            if (in_array($field, $date_fields)) {
                $value1 = (new Carbon($value1))->format('Y-m-d');
                $value2 = (new Carbon($value2))->format('Y-m-d');
            }

            if ($value1 !== $value2) {
                return true;
            }
        }
        return false;
    }

    public function getCurrentHistory(string $modelClass,$session_name ,$current_user_id, $issue_date_column, $expiry_date_column)
    {

        $max_expiry_date = EmployeePensionHistory::where('user_id', $current_user_id)
        ->where($issue_date_column, '<', now())
        ->max($expiry_date_column);

        $max_expiry_date_ids = EmployeePensionHistory::where('user_id', $current_user_id)
        ->where($issue_date_column, '<', now())
        ->where($expiry_date_column, $max_expiry_date)
        ->pluck('id');

        $max_issue_date = EmployeePensionHistory::where('user_id', $current_user_id)
        ->whereIn("id",$max_expiry_date_ids)
        ->max($issue_date_column);

         $max_id = EmployeePensionHistory::where('user_id', $current_user_id)
         ->whereIn("id",$max_expiry_date_ids)
        ->where($issue_date_column, $max_issue_date)
        ->max('id');

       $model = new $modelClass;
       $current_data = $model::where('id', $max_id)
       ->where('user_id', $current_user_id)
       ->orWhere(function($query) use($current_user_id) {
        $query
        ->where('user_id', $current_user_id)
        ->where("pension_eligible",0);
       })
       ->orderByDesc($issue_date_column)
        ->first();
        Session::put($session_name, $current_data?$current_data->id:NULL);
        return $current_data;

    }








}
