<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;

class UsersExport implements FromCollection
{
    protected $users;

    public function __construct($users)
    {
        $this->users = $users;
    }

    public function collection()
    {
        return $this->users;
    }

    public function map($user): array
    {
        // Define the fields you want to include
        return [
            $user->id,
            // $user->name,
            $user->email,
            // Add properties from related models if needed
            // Example: $user->profile->phone,
        ];
    }
}
