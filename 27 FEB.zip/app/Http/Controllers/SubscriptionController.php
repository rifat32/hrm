<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe\Checkout\Session;
use Stripe\Stripe;


class SubscriptionController extends Controller
{
    public function redirectUserToStripe(Request $request) {
        Stripe::setApiKey(config('services.stripe.secret'));
        $session = Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [
                [
                    'price_data' => [
                        'currency' => 'usd',
                        'product_data' => [
                            'name' => 'Your Product Name',
                        ],
                        'unit_amount' => 1000, // Amount in cents
                    ],
                    'quantity' => 1,
                ],
            ],
            'mode' => 'payment',
            'success_url' => route('subscription.success_payment'),
            'cancel_url' => route('subscription.failed_payment'),
        ]);

        return redirect()->to($session->url);
    }



    public function stripePaymentSuccess (Request $request) {
        return "success";
    }
    public function stripePaymentFailed (Request $request) {
        return "fail";
    }
}
