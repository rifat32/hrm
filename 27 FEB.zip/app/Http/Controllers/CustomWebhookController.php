<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Laravel\Cashier\Http\Controllers\WebhookController;
use Stripe\Event;
use Symfony\Component\HttpFoundation\Response;

class CustomWebhookController extends WebhookController
{
/**
     * Handle a Stripe webhook call.
     *
     * @param  Event  $event
     * @return \Symfony\Component\HttpFoundation\Response
     */

     protected function handleCustomerSubscriptionUpdated(array $payload)
     {
         $customer = $payload['data']['object']['customer'];

         // handle the incoming event...

         return new Response('Webhook Handled', 200);
     }

    public function handleStripeWebhook(Event $event)
    {
        // You can handle different types of Stripe events here
        // For example:
        if ($event->type === 'payment_intent.succeeded') {
            $this->handlePaymentIntentSucceeded($event->data->object);
        }



        return $this->successMethod();
    }

    /**
     * Handle payment succeeded webhook from Stripe.
     *
     * @param  \Stripe\PaymentIntent  $paymentIntent
     * @return void
     */
    protected function handlePaymentIntentSucceeded($paymentIntent)
    {
        // Handle payment succeeded event
        // Store payment information in your database
        $user = $this->getUserByStripeId($paymentIntent->customer);
        Log::info("stripe ...................");
        // $user->invoices()->create([
        //     'amount' => $paymentIntent->amount,
        //     'currency' => $paymentIntent->currency,
        //     'payment_intent_id' => $paymentIntent->id,
        //     // Add any additional information you want to store
        // ]);
    }


}
