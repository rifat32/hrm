<?php

namespace App\Http\Requests;

use App\Models\SocialSite;
use App\Models\User;
use App\Models\UserSocialSite;
use Illuminate\Foundation\Http\FormRequest;

class UserSocialSiteUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        [
            'id' => [
                'required',
                'numeric',
                function ($attribute, $value, $fail) {
                    $exists = UserSocialSite::where('id', $value)
                        ->where('user_social_sites.user_id', '=', $this->user_id)
                        ->exists();

                    if (!$exists) {
                        $fail("$attribute is invalid.");
                    }
                },
            ],
            'social_site_id' => [
            'required',
            'numeric',
            function ($attribute, $value, $fail) {
                $exists = SocialSite::where('id', $value)
                    ->where('sicial_sites.is_active',1)
                    ->exists();

                if (!$exists) {
                    $fail("$attribute is invalid.");
                }
            },
        ],
        'user_id' => [
            'required',
            'numeric',
            function ($attribute, $value, $fail) {
                $exists = User::where('id', $value)
                    ->where('users.business_id', '=', auth()->user()->business_id)
                    ->exists();

                if (!$exists) {
                    $fail("$attribute is invalid.");
                }
            },
        ],
        'profile_link' => "required|string",

    ];
    }
}
