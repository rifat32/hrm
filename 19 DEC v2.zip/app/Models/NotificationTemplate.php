<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NotificationTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        "name",
        "type",
        "template",
        "link",
        "is_active",

    ];
    protected $casts = [
        'created_at' => 'datetime:d-m-Y H:i:s', // Specify your desired format
        'updated_at' => 'datetime:d-m-Y H:i:s',
    ];
}
