<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductGallery extends Model
{
    use HasFactory;

    protected $fillable = [
        "image",
        "product_id",
    ];
    protected $casts = [
        'created_at' => 'datetime:d-m-Y H:i:s', // Specify your desired format
        'updated_at' => 'datetime:d-m-Y H:i:s',
    ];
}
