<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DepartmentWorkShift extends Model
{
    use HasFactory;
    protected $fillable = [
        'work_shift_id', 'department_id'
    ];
    protected $casts = [
        'created_at' => 'datetime:d-m-Y H:i:s', // Specify your desired format
        'updated_at' => 'datetime:d-m-Y H:i:s',
    ];
}
