<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SettingPayrun extends Model
{
    use HasFactory;
    protected $fillable = [
        'payrun_period',
        'consider_type',
        'consider_overtime',

        "business_id",
        "is_active",
        "is_default",
        "created_by"
    ];
    protected $casts = [
        'created_at' => 'datetime:d-m-Y H:i:s', // Specify your desired format
        'updated_at' => 'datetime:d-m-Y H:i:s',
    ];
}
