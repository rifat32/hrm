<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Leave extends Model
{
    use HasFactory;
    protected $fillable = [
        'leave_duration',
        'day_type',
        'leave_type_id',
        'employee_id',
        'date',
        'note',
        'start_date',
        'end_date',
        'start_time',
        'end_time',
        'attachments',
        "status",
        "is_active",
        "business_id",
        "created_by"
    ];


    public function records(){
        return $this->hasMany(LeaveRecord::class,'leave_id', 'id');
    }
    public function employee() {
        return $this->belongsTo(User::class, "employee_id","id");
    }
    public function leave_type() {
        return $this->belongsTo(SettingLeaveType::class, "leave_type_id","id");
    }
    protected $casts = [
        'attachments' => 'array',
        'created_at' => 'datetime:d-m-Y H:i:s', // Specify your desired format
        'updated_at' => 'datetime:d-m-Y H:i:s',
    ];

}
