<?php

namespace App\Http\Utils;


use App\Models\Business;
use App\Models\Department;
use App\Models\Designation;
use App\Models\EmploymentStatus;
use App\Models\Role;
use App\Models\User;
use Exception;

trait BusinessUtil
{
    // this function do all the task and returns transaction id or -1



    public function businessOwnerCheck($business_id) {

        $businessQuery  = Business::where(["id" => $business_id]);
        if(!auth()->user()->hasRole('superadmin')) {
            $businessQuery = $businessQuery->where(function ($query) {
                $query->where('created_by', auth()->user()->id)
                      ->orWhere('owner_id', auth()->user()->id);
            });
        }

        $business =  $businessQuery->first();
        if (!$business) {
            return false;
        }
        return $business;
    }



    public function checkManager($id) {
        $user  = User::where(["id" => $id])->first();
        if (!$user){
            return [
                "ok" => false,
                "status" => 400,
                "message" => "Manager does not exists."
            ];
        }

        if ($user->business_id != auth()->user()->business_id) {
            return [
                "ok" => false,
                "status" => 403,
                "message" => "Manager belongs to another business."
            ];
        }
        if (!$user->hasRole("business_admin")){
            return [
                "ok" => false,
                "status" => 403,
                "message" => "The user is not a manager"
            ];
        }
        return [
            "ok" => true,
        ];
    }

    public function checkEmployees($ids) {
        $users = User::whereIn("id", $ids)->get();
        foreach ($users as $user) {
            if (!$user){
                return [
                    "ok" => false,
                    "status" => 400,
                    "message" => "Employee does not exists."
                ];
            }

            if ($user->business_id != auth()->user()->business_id) {
                return [
                    "ok" => false,
                    "status" => 403,
                    "message" => "Employee belongs to another business."
                ];
            }
            if (!$user->hasRole("business_admin") &&  !$user->hasRole("business_employee")){
                return [
                    "ok" => false,
                    "status" => 403,
                    "message" => "The user is not a employee"
                ];
            }
        }

        return [
            "ok" => true,
        ];
    }


    public function checkDepartment($id) {
        $department  = Department::where(["id" => $id])->first();
        if (!$department){
            return [
                "ok" => false,
                "status" => 400,
                "message" => "Department does not exists."
            ];
        }

        if ($department->business_id != auth()->user()->business_id) {
            return [
                "ok" => false,
                "status" => 403,
                "message" => "Department belongs to another business."
            ];
        }
        return [
            "ok" => true,
        ];
    }
    public function checkDepartments($ids) {
        $departments = Department::whereIn("id", $ids)->get();

        foreach ($departments as $department) {
            if (!$department) {
                return [
                    "ok" => false,
                    "status" => 400,
                    "message" => "Department does not exists."
                ];
            }

            if ($department->business_id != auth()->user()->business_id) {
                return [
                    "ok" => false,
                    "status" => 403,
                    "message" => "Department belongs to another business."
                ];
            }
        }

        return [
            "ok" => true,
        ];
    }

    public function checkUsers($ids,$is_admin) {
        $users = User::whereIn("id", $ids)
        ->get();

        foreach ($users as $user) {
            if (!$user) {
                return [
                    "ok" => false,
                    "status" => 400,
                    "message" => "User does not exists."
                ];
            }

            if($is_admin) {
                if ($user->business_id != NULL) {
                    return [
                        "ok" => false,
                        "status" => 403,
                        "message" => "User belongs to another business."
                    ];
                }
            }
            if(!$is_admin) {
            if ($user->business_id != auth()->user()->business_id) {
                return [
                    "ok" => false,
                    "status" => 403,
                    "message" => "User belongs to another business."
                ];
            }
            }


        }

        return [
            "ok" => true,
        ];
    }

    public function checkRoles($ids,$is_admin) {
        $roles = Role::whereIn("id", $ids)
        ->get();

        foreach ($roles as $role) {
            if (!$role) {
                return [
                    "ok" => false,
                    "status" => 400,
                    "message" => "Department does not exists."
                ];
            }

            if($is_admin) {
                if (!(($role->business_id == NULL) && ($role->is_default == 1))) {
                    return [
                        "ok" => false,
                        "status" => 403,
                        "message" => "Role belongs to another business."
                    ];
                }
            }
            if(!$is_admin) {
                if (!(($role->business_id == auth()->user()->business_id) && ($role->is_default == 0))) {
                    return [
                        "ok" => false,
                        "status" => 403,
                        "message" => "Role belongs to another business."
                    ];
                }
            }


        }

        return [
            "ok" => true,
        ];
    }


    public function storeDefaultsToBusiness($business_id) {

        $attached_defaults = [];


        $defaultRoles = Role::where([
            "business_id" => NULL,
            "is_default" => 1,
            "is_default_for_business" => 1
          ])->get();

          foreach($defaultRoles as $defaultRole) {
              $insertableData = [
                'name'  => ($defaultRole->name . "#" . $business_id),
                "is_default" => 1,
                "business_id" => $business_id,
                "is_default_for_business" => 0
              ];
           $role  = Role::create($insertableData);
           $attached_defaults["roles"][$defaultRole->id] = $role->id;

           $permissions = $defaultRole->permissions;
           foreach ($permissions as $permission) {
               if(!$role->hasPermissionTo($permission)){
                   $role->givePermissionTo($permission);
               }
           }


          }



        $defaultDesignations = Designation::where([
            "business_id" => NULL,
            "is_default" => 1,
            "is_active" => 1
          ])->get();

          foreach($defaultDesignations as $defaultDesignation) {
              $insertableData = [
                'name'  => $defaultDesignation->name,
                'description'  => $defaultDesignation->description,
                "is_active" => 1,
                "is_default" => 1,
                "business_id" => $business_id,
              ];
           $designation  = Designation::create($insertableData);
           $attached_defaults["designations"][$defaultDesignation->id] = $designation->id;
          }

          $defaultEmploymentStatuses = EmploymentStatus::where([
            "business_id" => NULL,
            "is_active" => 1,
            "is_default" => 1
          ])->get();

          foreach($defaultEmploymentStatuses as $defaultEmploymentStatus) {
              $insertableData = [
                'name'  => $defaultEmploymentStatus->name,
                'color'  => $defaultEmploymentStatus->color,
                'description'  => $defaultEmploymentStatus->description,
                "is_active" => 1,
                "is_default" => 1,
                "business_id" => $business_id,
              ];
           $employment_status  = EmploymentStatus::create($insertableData);
           $attached_defaults["employee_statuses"][$defaultEmploymentStatus->id] = $employment_status->id;
          }


    }



}
