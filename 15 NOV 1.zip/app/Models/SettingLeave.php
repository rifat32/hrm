<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SettingLeave extends Model
{
    use HasFactory;
    protected $fillable = [
        'start_month',
        'approval_level',
        'allow_bypass',
        // 'special_users',
        // 'special_roles',
        // 'paid_leave_employment_statuses',
        // 'unpaid_leave_employment_statuses',
    ];


}
