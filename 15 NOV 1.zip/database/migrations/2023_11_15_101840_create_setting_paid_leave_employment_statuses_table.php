<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSettingPaidLeaveEmploymentStatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('setting_paid_leave_employment_statuses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("setting_leave_id")->nullable();
            $table->foreign('setting_leave_id')->references('id')->on('setting_leaves')->onDelete('cascade');
            $table->unsignedBigInteger("employment_status_id");
            $table->foreign('employment_status_id')->references('id')->on('employment_statuses')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('setting_paid_leave_employment_statuses');
    }
}
