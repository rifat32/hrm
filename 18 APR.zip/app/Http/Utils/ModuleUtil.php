<?php

namespace App\Http\Utils;

use App\Models\Business;
use App\Models\Module;

trait ModuleUtil
{
    // this function do all the task and returns transaction id or -1
    public function isModuleEnabled($module_name)
    {
        $user = auth()->user();
        $query_params = [
            'name' => $module_name,
            'is_default' => 1,
            'business_tier_id' => null,
        ];

        if (!empty($user->business_id)) {
            $business = Business::find($user->business_id);

            if ($business) {
                $query_params["is_default"] = 0;
                $query_params["business_tier_id"] = $business->service_plan?$business->service_plan->business_tier->id:1;
            }
        }

        $module = Module::where($query_params)->first();
        return $module ? $module->is_enabled : false;

    }
}
