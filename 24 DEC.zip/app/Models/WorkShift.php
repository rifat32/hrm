<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkShift extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        "break_type",
        "break_hours",
        'type',
        "description",
        'attendances_count',
        'is_business_default',
        'is_personal',

        'start_date',
        'end_date',

        "is_active",
        "business_id",
        "created_by"

    ];

    protected $dates = ['start_date',
    'end_date',];


    public function details(){
        return $this->hasMany(WorkShiftDetail::class,'work_shift_id', 'id');
    }

    public function departments() {
        return $this->belongsToMany(Department::class, 'department_work_shifts', 'work_shift_id', 'department_id');
    }
    public function users() {
        return $this->belongsToMany(User::class, 'user_work_shifts', 'work_shift_id', 'user_id');
    }


    public function getCreatedAtAttribute($value)
    {

        return (new Carbon($value))->format('d-m-Y');
    }
    public function getUpdatedAtAttribute($value)
    {

        return (new Carbon($value))->format('d-m-Y');
    }

    public function getStartDateAttribute($value)
    {

        return (new Carbon($value))->format('d-m-Y');
    }

    public function getEndDateAttribute($value)
    {

        return (new Carbon($value))->format('d-m-Y');
    }






    public function setStartDateAttribute($value)
    {

        $this->attributes['start_date'] = (new Carbon($value))->format('Y-m-d');
    }

    public function setEndDateAttribute($value)
    {

        $this->attributes['end_date'] = (new Carbon($value))->format('Y-m-d');
    }

    protected static function boot()
    {
        parent::boot();

        // Event when saving to the database
        static::saving(function ($model) {
            $model->attributes['start_date'] = Carbon::createFromFormat('d-m-Y', $model->attributes['start_date'])->format('Y-m-d');
        });

        // Event after retrieving from the database
        static::retrieved(function ($model) {
            if (!empty($model->attributes['start_date']) && Carbon::hasFormat($model->attributes['start_date'], 'Y-m-d')) {
                $model->attributes['start_date'] = Carbon::parse($model->attributes['start_date'])->format('d-m-Y');
            }

        });
    }
}
