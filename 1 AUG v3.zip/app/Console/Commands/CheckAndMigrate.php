<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schema;

class CheckAndMigrate extends Command
{
    protected $signature = 'check:migrate';
    protected $description = 'Check if tables exist before running migrations';

    public function handle()
    {
        $migrationFiles = glob(database_path('migrations/*.php'));

        foreach ($migrationFiles as $file) {
            $contents = file_get_contents($file);

            if (preg_match('/Schema::create\(\'([^\']+)\'/', $contents, $matches)) {
                $table = $matches[1];

                if (Schema::hasTable($table)) {
                    $this->info("Table {$table} already exists. Skipping migration.");
                } else {
                    $this->info("Migrating {$file}");
                    Artisan::call('migrate', [
                        '--path' => str_replace(base_path(), '', $file),
                    ]);
                }
            } else {
                $this->warn("No create statement found in {$file}. Skipping.");
            }
        }
    }
}
